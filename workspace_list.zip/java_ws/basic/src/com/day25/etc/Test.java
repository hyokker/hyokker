//package com.day25.etc;
//
//class Anonymous2 extends Frame{ 
//	Button btn;	
//	public Anonymous2(){
//		btn=new Button("�� ��");
//		add(btn,"South");
//		btn.addActionListener(new EventHandler());
//	} 
//	class new ActionListener()
//	class EventHandler implements ActionListener{
//		public void actionPerformed(ActionEvent e) {
//			System.exit(0);
//		}
//	}
//}//class
//
//
//
