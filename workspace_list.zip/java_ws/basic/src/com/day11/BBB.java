package com.day11;

public class BBB {
	private int x=100;
	int y=200;
	protected int z=300;
	public int n=400;
	
	public void showInfo() {
		System.out.println("x = " + x);
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		System.out.println("n = " + n);
		
	}
}
