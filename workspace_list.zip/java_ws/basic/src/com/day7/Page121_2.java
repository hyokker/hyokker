package com.day7;

public class Page121_2 {

	public static void main(String[] args) {
		int sum = 0;
//		for(int i=1;i<6;i++) {
//			for(int j=1;j<6;j++) {
//				sum++;
//				System.out.print(sum+"\t");
//			}
//			System.out.println("");
//			}
		for(int i=1;i<=25;i++) {
			System.out.print(i+ "\t");
			if(i%5==0) {
				System.out.println("");
			}
		}
	}
}


//			sum = i;