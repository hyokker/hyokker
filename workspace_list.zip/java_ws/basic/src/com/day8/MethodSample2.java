package com.day8;

public class MethodSample2 {
	public static void x(){
		 for(int i=0;i<5;i++) {
				System.out.print("*");
		}
	}
	public static void main(String[] args) {
		x();
		System.out.println("\nHello");
	
		x();
		System.out.println("\nJava");
	
		x();
		System.out.println("\n!!!!!!!!!!!!!!!!");
	
		x();
		
	}
}
