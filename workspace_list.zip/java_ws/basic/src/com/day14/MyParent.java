package com.day14;

public class MyParent {
	private int num1;
	protected int num2;
	int num3;
	public int num4;
}
