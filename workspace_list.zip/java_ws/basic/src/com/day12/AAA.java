package com.day12;

public class AAA {
	private int x=10;
	int y=20;
	protected int z=30;
	public int n=40;
	
	public void showInfo() {
		System.out.println("x = " + x);
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		System.out.println("n = " + n);
		
	}
}
