//package com;
//class MyTest1 {
//
//	protected String name;
//	int age;
//	public String job;
//
//	public  void display() {
//		System.out.println("MyTest1 �޼���");
//	}
//}
