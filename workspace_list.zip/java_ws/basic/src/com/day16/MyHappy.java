////package com.happy;
//public class MyHappy {
//	public  void display() {
//		System.out.println("MyHappy �޼���");
//	}
//}
