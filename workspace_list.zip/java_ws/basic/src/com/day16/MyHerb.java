//package com.herb;
//public class MyHerb {
//	protected String tel;
//	int grade;
//	public String addr;
//
//	public  void display() {
//		System.out.println("MyHerb �޼���");
//	}
//}
////