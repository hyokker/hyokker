/* doesn't work with source level 1.8:
module com.ez.swingapp {
    requires javafx.controls;
    exports com.ez.swingapp;
}
*/
