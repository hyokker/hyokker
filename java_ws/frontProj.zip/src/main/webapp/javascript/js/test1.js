/**
 * js/test1.js
 */
 
 document.write("<h2>외부 자바스크립트 파일에서 작성</h2>");