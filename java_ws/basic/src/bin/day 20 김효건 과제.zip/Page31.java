package com.Hw;

abstract class Shape{
	Point p;
	Shape(){
		this(new Point(0,0));
	}
	Shape(Point p){
		this.p=p;
	}
	
	Point getP() {
		return p;
	}
	void setP(Point p) {
		this.p=p;
	}
	
	abstract double calcArea(); //���� ���� ���
}

class Point{
	private int x;
	private int y;
	
	Point(){
		this(0,0);
	}
	Point(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	public String findInfo() {
		return "["+x+","+y+"]";
	}
}

class Rect extends Shape{
	private	int w,h;
	
	Rect(int w, int h){
		this(new Point(w,h), w , h);
	}
	Rect(Point p, int w, int h){
		super(p);
		this.w=w;
		this.h=h;
	}
	
	public double calcArea() {
		return w*h;	
	}
	public boolean isSquare() {
		if(w==h) {
			return true;
		}else {
			return false;
		}
	}
}

class Circle extends Shape{
	private double r;
	
	Circle(double r){
		this(new Point(0,0), r);
	}
	Circle(Point p,double r){
		super(p);
		this.r=r;
	}
	public double calcArea() {
		return r*r*3.14;
	}
}

class Exercise{
	//sumArea �޼��� �ۼ�
	public static  double sumArea(Shape[] arr) {
		double sum=0;
		for(int i=0;i<arr.length;i++) {
			sum+=arr[i].calcArea();
		}
		return sum;	
	}
	
}
public class Page31 {

	public static void main(String[] args) {
		Exercise e = new Exercise();
		Shape[] arr= {new Circle(5.2),new Rect(3, 4), new Circle(1)};
		System.out.println("������ �� : "+e.sumArea(arr));
	}


	


}
