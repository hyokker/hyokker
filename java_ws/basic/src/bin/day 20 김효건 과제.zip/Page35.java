package com.Hw;

import java.util.Scanner;

class Pitcher {
	int[] answer = new int[3];

	public void Answer() {
		for (int i = 0; i < answer.length; i++) {
			answer[i] = (int) (Math.random() * 9);
			for (int j = 0; j < i; j++) {
				if (answer[i] == answer[j])
					i--; // �ߺ�����
			}
		}
	}

}

class Hitter {
	int[] user = new int[3];

	Hitter(int num1, int num2, int num3) {
		this.user[0] = num1;
		this.user[1] = num2;
		this.user[2] = num3;
	}
}

class Umpire {

	public int getStrike(Pitcher p, Hitter h) {
		int strike = 0;
		for (int i = 0; i < 3; i++) {
			if (p.answer[i] == h.user[i]) {
				strike++;
			}
		} // for
		return strike;
	}

	public int getBall(Pitcher p, Hitter h) {
		int ball = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (i != j) {
					if (p.answer[i] == h.user[j])
						ball++;
				}
			} // ���� for
		} // �ٱ��� for
		return ball;
	}
}

public class Page35 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Hitter h = null;
		Umpire u = new Umpire();

		while (true) {
			Pitcher p = new Pitcher();
			p.Answer();
			for (int i = 0; i < 10; i++) {
				System.out.println("�ٸ� �� ���� �Է��ϼ���");
				h = new Hitter(sc.nextInt(), sc.nextInt(), sc.nextInt());

				int strike = u.getStrike(p, h);
				if (strike == 3) {
					System.out.println("YOU WIN IN" + i + 1);
					break;
				}
				int ball = u.getBall(p, h);
				System.out.println("�ݺ�ȸ�� :" + (i + 1) + "," + strike + "Strike!!" + ball + "Ball!!!");
				
				if(i==9) {
					System.out.println("You Lose, Pitcher is");
					System.out.println(p.answer[0] + "\t" + p.answer[1] + "\t" + p.answer[2]);
					break;
				}

			} // for

			System.out.println("����Ͻðڽ��ϱ�? Y/N");
			String quit = sc.nextLine();
			if (quit.equalsIgnoreCase("Y"))
				return;
		} // while

	}

}
