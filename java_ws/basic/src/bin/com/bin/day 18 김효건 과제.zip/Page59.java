package com.Hw;

import java.util.Scanner;

abstract class Account {
	protected String accNo;
	protected double balance;

	public Account(String accNo, double balance) {
		this.accNo = accNo;
		this.balance = balance;
	}

	public void deposit(double money) 
	{
		balance += money;
	}

	public void withdraw(double money)  
	{
		balance -= money;
	}

	public void display() {
		System.out.println("���¹�ȣ:" + accNo);
		System.out.println("�����ܾ�:" + (int)balance);
	}
}
class Account2 extends Account{
	Account2(String accNo, double balance) {
		super(accNo, balance);
	}

	public void display() {
		System.out.println("���¹�ȣ:" + accNo);
		System.out.println("�����ܾ�:" + (int)balance);
	}
}
class FaithAccount extends Account{

	FaithAccount(String accNo, double balance) {
		super(accNo,balance);
		this.balance=balance+balance*0.01;
	}
	public void deposit(double money) {
		balance += money+money*0.01;
	}
}

class ContriAccount extends Account{
	private double contribution;
	
	 ContriAccount(String accNo, double balance) {
		 super(accNo,balance-balance*0.01);
		 this.contribution=balance*0.01;
	}
	 
	 public void deposit(double money) {
		 super.deposit(money-money*0.01);
		 contribution+=money*0.01;
	 }
	 public void display() {
			System.out.println("���¹�ȣ:" + accNo);
			System.out.println("�����ܾ�:" + (int)balance);
			System.out.println("�� ��ξ�:" + (int)contribution);
	}
}
public class Page59 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("������ �������� - �Ϲݰ���<A>,�ſ����<F>,��ΰ���<C>, ���¹�ȣ, �ܾ��� �Է��ϼ���");
		String type= sc.nextLine();
		String accNo = sc.nextLine();
		int balance = sc.nextInt();
		System.out.println("==============");
		if(type.equalsIgnoreCase("A")) {
			Account a = new Account2(accNo, balance);
			a.display();
			System.out.println("�Ա��� �ݾ��� �Է�!");
			int money=sc.nextInt();
			a.deposit(money);
			a.display();	
		}else if(type.equalsIgnoreCase("F")) {
			Account a = new FaithAccount(accNo, balance);
			a.display();
			System.out.println("�Ա��� �ݾ��� �Է�!");
			int money=sc.nextInt();
			a.deposit(money);
			a.display();
		}else if(type.equalsIgnoreCase("C")) {
			Account a = new ContriAccount(accNo, balance);
			a.display();
			System.out.println("�Ա��� �ݾ��� �Է�!");
			int money=sc.nextInt();
			a.deposit((int)money);
			a.display();
		}
		
	}
}
