package com.Hw;

import java.util.ArrayList;
import java.util.Scanner;

abstract class Accountt{
	protected String accId;
	protected int balance;
	protected String name;
	
	Accountt(String accId, int balance, String name){
		this.accId=accId;
		this.balance=balance;
		this.name=name;		
	}
	
	public int getBalance() {
		return balance;
	}
	
	public String getName() {
		return name;
	}
	public String accId() {
		return accId;
	}
	
	public void deposit(int money) {
		balance+=money;
	}
	public int withdraw(int money) {
		if(money>balance) {
			return 0;
		}else {
			balance-=money;
		}
		return balance;
	}
	
	public void showInfo() {
		System.out.println("���¹�ȣ" + accId);
		System.out.println("�ܾ�" + balance);
		System.out.println("�����̸�" + name);
	}
}

class NormalAccount extends Accountt{
	protected int rate;
	
	NormalAccount(String accId,int balance,String name, int rate) {
	super(accId,balance,name);
	this.rate=rate;
	}
	
	public void deposit(int money) {
		balance+=money+(money*this.rate/100);
	}
	
	public void showInfo() {
		super.showInfo();
		System.out.println("������ : " + rate +"%");
	}
}
interface grade{
	int A = 3, B = 2 , C = 1;
}
class HighCreditAccount extends NormalAccount{
	private int special_rate;
	
	HighCreditAccount(String accId,int balance,String name, int rate, int g){
	super(accId,balance,name,rate);
	if (g == 1) {
		special_rate = grade.A;
	} else if (g == 2) {
		special_rate = grade.B;
	} else if (g == 3) {
		special_rate = grade.C;
	} else {
		System.out.println("�߸��Է�");
		return;
	}
}
	
	
	public void deposit(int money) {
		balance+=money+(money*super.rate/100)+(money*this.special_rate/100);
	}
	public void showInfo() {
		super.showInfo();
		System.out.println("Ư�� ������ :" + special_rate + "%");
	}
	
	
}

class AccountManager{
	ArrayList<Accountt> acclist = new ArrayList<Accountt>();
	Scanner sc = new Scanner(System.in);
	
	public void showMenu() {
		System.out.println("1. ���� ����");
		System.out.println("2. ��\t��");
		System.out.println("3. ��\t��");
		System.out.println("4. �������� ��ü ���");
		System.out.println("5. ���α׷� ����");
		System.out.print("����");
	}
	
	public void openAcc() {
		System.out.println("[�������� ����]");
		System.out.println("1.���� ���ݰ���");
		System.out.println("2.�ſ� �ŷڰ���");
		int type=sc.nextInt();
		sc.nextLine();
		switch(type) {
			case 1:
				System.out.println("���� ���ݰ��� ����");
				System.out.print("���� :");
				String accId=sc.nextLine();
				System.out.print("�̸� :");
				String name=sc.nextLine();
				System.out.print("�Աݾ� :");
				int money=sc.nextInt();
				System.out.print("������ :");
				int rate=sc.nextInt();
				sc.nextLine();
				
				acclist.add(new NormalAccount(accId, money, name, rate));
				break;
			case 2 :
				System.out.println("�ſ� �ŷڰ��� ����");
				sc.nextLine();
				System.out.print("���� :");
				accId=sc.nextLine();
				System.out.print("�̸� :");
				name=sc.nextLine();
				System.out.print("�Աݾ� :");
				money=sc.nextInt();
				System.out.print("������ :");
				rate=sc.nextInt();
				
				System.out.println("�ſ��� 1toA , 2toB, 3toC");
				int g =sc.nextInt();
				
				acclist.add(new HighCreditAccount(accId, money, name, rate, g));
				break;
				
		}
	}
	
	public void inputMoney() {
		System.out.println("��\t��");
		System.out.print("���� :");
		String accId = sc.nextLine();
		System.out.print("�Աݾ� : ");
		int balance = sc.nextInt();
		sc.nextLine();
		
		for(int i=0;i<acclist.size();i++) {
			Accountt a=acclist.get(i);
			if(accId.equals(a.accId)) {
			a.deposit(balance);
			}else {
				System.out.println("��ȿ���� ���� �����Դϴ�.");
			}
		}
		
	}
	
	public void outputMoney() {
		System.out.println("��\t��");
		System.out.print("���� :");
		String accId = sc.nextLine();
		System.out.print("��ݾ� : ");
		int money = sc.nextInt();
		
		for(int i=0;i<acclist.size();i++) {
			Accountt a = acclist.get(i);
			if(accId.equals(a.accId)) {
				if(a.balance<money) {
					System.out.println("�ܾ��� �����մϴ�");
				}else {
					a.withdraw(money);
					
				}
			}
		}
	}
	
	public void totalShow() {
		if(acclist.isEmpty()) {
			System.out.println("���������� �����ϴ�"); 
			return;
		}
		System.out.println("\n\n=========��ü ���� ���� ==========");
		for(int i=0;i<acclist.size();i++) {
			acclist.get(i).showInfo();
			System.out.println("=======================");
		}
	}
}
public class Page34 {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		AccountManager am = new AccountManager();
		
		while(true) {
			am.showMenu();
			int type=sc.nextInt();
				switch(type) {
				case 1 :
						am.openAcc();
						break;
				case 2 :
						am.inputMoney();
						break;
				case 3 :
						am.outputMoney();
						break;
				case 4 :
						am.totalShow();
						break;
				case 5 : 
						System.out.println("�����մϴ�");
						return;
				default :
						System.out.println("�߸� �Է�");
						break;
				}
		}
	}

}
