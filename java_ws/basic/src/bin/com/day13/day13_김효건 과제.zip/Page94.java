package com.day13;

import java.util.Scanner;

class PhoneInfo{
	String name;
	String phone;
	String birth;
	
	PhoneInfo(String name,String phone, String birth){
		this.name=name;
		this.phone=phone;
		this.birth=birth;
	}
	PhoneInfo(String name,String phone){
		this.name=name;
		this.phone=phone;
	}
	
	public void showInfo() {
		System.out.println("name : " + name);
		System.out.println("phone : " + phone);
		if(birth != null)System.out.println("birth : " + birth);
	}
}
public class Page94 {

	public static void main(String[] args) {
		PhoneInfo p = new PhoneInfo("ȫ�浿", "010-100-2000","92-01-17");
		
		PhoneInfo p2 = new PhoneInfo("�迬��", "010-300-4000");
		
		p.showInfo();
		
		p2.showInfo();
	}

}
