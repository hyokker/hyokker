package com.Hw;

import java.util.Scanner;

class FoodSale{
	protected String menu;
	protected int cnt;//����
	protected int cost;//�ܰ�
	protected int saleCount;//�ǸŰ���
	
	FoodSale(int cnt, int cost){
		this.cnt=cnt;
		this.cost=cost;
	}
	public static int totalSaleCount;//�Ѿ�
	
	public int getFindSaleCount() {
		return this.saleCount;
	}
	public void findSaleCount() {
		this.saleCount=cnt*cost;
	}
	
	public void findTotalSaleCount() {
		FoodSale.totalSaleCount+=saleCount;
	}
	public int getTotalSaleCount() {
		return totalSaleCount;
	}
}

class StudentFoodSale extends FoodSale{
	private int discountCost;
	public static int totlaDiscountCost;
	public static double TOTALSALE_RATE=0.1;

	
	StudentFoodSale(int cnt, int cost){
		super(cnt,cost);
	}
	public void findSaleCount() {
		this.discountCost=(int) (super.cnt*super.cost*TOTALSALE_RATE);
		super.saleCount=super.cnt*super.cost-discountCost;
	}
	public void findTotalSaleCount() {
		FoodSale.totalSaleCount+=saleCount;
	}
	public int getTotalSaleCount() {
		return FoodSale.totalSaleCount+=saleCount;
	}
	public void findTotalDiscountCost() {
		this.totlaDiscountCost+=discountCost;
	}
	public int getTotalDiscountCost() {
		return this.totlaDiscountCost;
	}
}

	
public class Page53 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("�޴�, ����, �ܰ�, �л�����(Y/N)�� �Է��ϼ���!");
			String name=sc.nextLine();
			int cnt = sc.nextInt();
			int cost = sc.nextInt();
			sc.nextLine();
			String ok = sc.nextLine();
			if(ok.equalsIgnoreCase("Y")) {
				StudentFoodSale f = new StudentFoodSale(cnt,cost);
				f.findSaleCount();
				
				System.out.print("�Ǹűݾ� :" + f.getFindSaleCount());
				System.out.print("���� �Ǹűݾ� :" + f.getTotalSaleCount());
				f.findTotalDiscountCost();
				System.out.print("���� ���� �ݾ� :" + f.getTotalDiscountCost());
				
				System.out.println("\n�׸��Ͻðڽ��ϱ�?<Q>uit");
				String quit = sc.nextLine();
				if(quit.equalsIgnoreCase("Q")) {
					break;
					} 
			
			
			
			
			}else if(ok.equalsIgnoreCase("N")) {
				FoodSale fs = new FoodSale(cnt,cost);
				fs.findSaleCount();
				System.out.print("�Ǹűݾ� :" + fs.getFindSaleCount());
				fs.findTotalSaleCount();
				System.out.print("�����Ǹűݾ� :" + fs.getTotalSaleCount());
				
				System.out.println("\n�׸��Ͻðڽ��ϱ�?<Q>uit");
				String quit = sc.nextLine();
				if(quit.equalsIgnoreCase("Q")) {
					break;
				}
			}
		}
	}

}
