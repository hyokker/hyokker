package com.Hw;
class Human{
	public void work() {
		
	}
}

class Teacher extends Human{
	public void work() {
		System.out.println("����ġ�� ���� �մϴ�.\n");
	}
}

class Programmer extends Human{
	public void work() {
		System.out.println("���α׷����� �մϴ�");
	}
}
public class Page24 {

	public static void main(String[] args) {
		Teacher t = new Teacher();
		
		t.work();
		
		Programmer p = new Programmer();
		
		p.work();
	}

}
