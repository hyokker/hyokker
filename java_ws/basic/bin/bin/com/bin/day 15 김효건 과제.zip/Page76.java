package com.Hw;

import java.util.Scanner;

class Account5{
	protected String accNum;
	protected int accMoney;
	
	public String getAccNum() {
		return accNum;
	}
	
	public void setAccNum(String accNum) {
		this.accNum=accNum;
	}
	
	public int getAccMoney() {
		return accMoney;
	}
	
	public void setAccMoney(int accMoney) {
		this.accMoney=accMoney;
	}
}

class KBAccount extends Account5{
	private int transferLimit;
	
	public int getTransferLimit() {
		return transferLimit;
	}
	
	public void setTransferLimit(int transferLimit) {
		this.transferLimit=transferLimit;
	}
	
	public void showInfo() {
		System.out.println("���¹�ȣ : " + accNum);
		System.out.println("�ܾ� : " + accMoney);
		System.out.println("��ü�ѵ� : " + transferLimit);
	}
}
public class Page76 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("���¹�ȣ, �ܾ�, ��ü�ѵ� �Է�");
		String accNum=sc.nextLine();
		int accMoney=sc.nextInt();
		int transferLimit=sc.nextInt();
		
		KBAccount KA= new KBAccount();
		
		KA.setAccNum(accNum);
		KA.setAccMoney(accMoney);
		KA.setTransferLimit(transferLimit);
		
		
		System.out.println("======================");
		KA.showInfo();
	}

}
