import java.util.*;
class dan 
{
	public static void main(String[] args){
for (int i=1;i<=30; i++) {
	if(i%4==0 || i%6==0){
		System.out.print(i+"\t");
	}
}
	}
}
